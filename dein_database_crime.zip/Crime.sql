
/*****SCRIPTS FOR TASK 3*****/


--Transaction Isolation Level
USE [ADB Task 3];  
GO  
SET TRANSACTION ISOLATION LEVEL READ COMMITTED;

--- Greater manchester crime tables
SELECT *
 FROM [ADB Task 3].[dbo].[Full greater manchester street]

--Population table
 SELECT *
 FROM [Mid-2020 Persons]

 ---Media age table
  SELECT *
 FROM [Median Age]


 --Script for adding new column 'Geolocation' with Geography data type
 ALTER TABLE [Full greater manchester street]
 ADD [Geolocation] GEOGRAPHY


 --- Creating an instance of Geography point on the Geolocation point for Spatial analysis
 UPDATE [Full greater manchester street]
SET [Geolocation] = geography::Point(Latitude, Longitude, 4326)
WHERE [Longitude] IS NOT NULL
AND [Latitude] IS NOT NULL
AND CAST(Latitude AS decimal(10, 6)) BETWEEN -90 AND 90
AND CAST(Longitude AS decimal(10, 6)) BETWEEN -90 AND 90


---Adding Primary key constraint to table for geospatial analysis
ALTER TABLE [Full greater manchester street]
ADD ID INT IDENTITY;
ALTER TABLE [Full greater manchester street]
ADD CONSTRAINT PK_Id PRIMARY KEY NONCLUSTERED (ID);
GO

--All Views

---Vehcile crime View
CREATE View Vechicle_crime
AS
SELECT c.ID, [Crime type], p.[LSOA Name], a.[Median Age],p.[LSOA Code],p.[LA name (2021 boundaries)],c.Longitude,c.Latitude,c.Month, c.Geolocation
FROM [Full greater manchester street] c
INNER JOIN [Mid-2020 Persons]  p
ON c.[LSOA code] = p.[LSOA code] 
INNER JOIN [Median Age] a ON
c.[LSOA code] = a.[LSOA code]
WHERE [Crime type] = 'Vehicle crime'


--Anti social behaviour crime in Salford
CREATE View [Anti-social behaviour salford]
AS
SELECT c.ID,[Crime type], p.[LSOA Name], a.[Median Age],p.[LSOA Code],p.[LA name (2021 boundaries)],c.Month, C.Geolocation
FROM [Full greater manchester street] c
INNER JOIN [Mid-2020 Persons]  p
ON c.[LSOA code] = p.[LSOA code] 
INNER JOIN [Median Age] a ON
c.[LSOA code] = a.[LSOA code]
WHERE [Crime type] = 'Anti-social behaviour' AND p.[LSOA name] LIKE'%salford%'


---Shoplifting View for Greater Manchester
CREATE View Shoplifting
AS
SELECT [Crime type], p.[LSOA Name], a.[Median Age],p.[LSOA Code],p.[LA name (2021 boundaries)],c.Longitude,c.Latitude,c.Month,c.Geolocation
FROM [Full greater manchester street] c
INNER JOIN [Mid-2020 Persons]  p
ON c.[LSOA code] = p.[LSOA code] 
INNER JOIN [Median Age] a ON
c.[LSOA code] = a.[LSOA code]
WHERE [Crime type] = 'Shoplifting'

---Burglary View for Greater Manchester
CREATE View [Burglary crime]
AS
SELECT [Crime type] as Burglary, p.[LSOA Name], a.[Median Age],p.[LSOA Code],p.[LA name (2021 boundaries)],c.Longitude,c.Latitude,c.Month,c.Geolocation
FROM [Full greater manchester street] c
INNER JOIN [Mid-2020 Persons]  p
ON c.[LSOA code] = p.[LSOA code] 
INNER JOIN [Median Age] a ON
c.[LSOA code] = a.[LSOA code]
WHERE [Crime type] = 'Burglary'


---TOP 10 CRIMES IN GM
SELECT TOP (10) c.[Crime type], COUNT([Crime type]) AS [Crime count]
FROM [Full greater manchester street] c
INNER JOIN [Mid-2020 Persons]  p
ON c.[LSOA code] = p.[LSOA code] 
GROUP BY c.[Crime type]
ORDER BY 2 DESC


---TOP 10 CRIME PRONE AREAS IN GM
SELECT TOP (10) p.[LA name (2021 boundaries)], COUNT([Crime type]) AS [Crime count]
FROM [Full greater manchester street] c
INNER JOIN [Mid-2020 Persons]  p
ON c.[LSOA code] = p.[LSOA code] 
GROUP BY p.[LA name (2021 boundaries)]
ORDER BY 2 DESC



---Shoplifting in Greater Manchester
SELECT COUNT([Crime type]) AS [Shoplifting],p.[LA name (2021 boundaries)]
FROM [Full greater manchester street] c
INNER JOIN [Mid-2020 Persons]  p
ON c.[LSOA code] = p.[LSOA code] 
INNER JOIN [Median Age] a ON
c.[LSOA code] = a.[LSOA code]
WHERE [Crime type] = 'Shoplifting'
GROUP BY p.[LA name (2021 boundaries)]
ORDER BY 1 DESC

--Median age of shoplifters
SELECT TOP (10) COUNT([Crime type]) AS [Shoplifting], a.[median age]
FROM [Full greater manchester street] c
INNER JOIN [Mid-2020 Persons]  p
ON c.[LSOA code] = p.[LSOA code] 
INNER JOIN [Median Age] a ON
c.[LSOA code] = a.[LSOA code]
WHERE [Crime type] = 'Shoplifting'
GROUP BY a.[median age]
ORDER BY 1 DESC 


---Vehicle crime in Greater Manchester
SELECT COUNT([Crime type]) AS [Vehicle crime],p.[LA name (2021 boundaries)]
FROM [Full greater manchester street] c
INNER JOIN [Mid-2020 Persons]  p
ON c.[LSOA code] = p.[LSOA code] 
WHERE [Crime type] = 'Vehicle crime'
GROUP BY p.[LA name (2021 boundaries)]
ORDER BY 1 DESC

--Anti social behaviour in Greater manchester
SELECT COUNT([Crime type]) AS [Anti-social behaviour],p.[LA name (2021 boundaries)]
FROM [Full greater manchester street] c
INNER JOIN [Mid-2020 Persons]  p
ON c.[LSOA code] = p.[LSOA code] 
WHERE [Crime type] = 'Anti-social behaviour' 
GROUP BY p.[LA name (2021 boundaries)]
ORDER BY 1 DESC


---Stored Procedure 

CREATE PROCEDURE [Top 10 Crimes by City] @City nvarchar(30)
AS
SELECT TOP (10) c.[Crime type], COUNT([Crime type]) AS [Crime count]
FROM [Full greater manchester street] c
INNER JOIN [Mid-2020 Persons]  p
ON c.[LSOA code] = p.[LSOA code] 
WHERE C.[LSOA name] LIKE '%' + @City + '%'
GROUP BY c.[Crime type]
ORDER BY 2 DESC
GO

EXEC [Top 10 Crimes by City] @city	= 'salford'


--Triggers

CREATE TRIGGER error101 
ON [Full greater manchester street]
AFTER INSERT, UPDATE, DELETE  
AS RAISERROR ('Notify DBA', 16, 10); 
ROLLBACK TRANSACTION; 
GO 
CREATE TRIGGER error102 
ON [Mid-2020 Persons]
AFTER INSERT, UPDATE, DELETE  
AS RAISERROR ('Notify DBA', 16, 10); 
ROLLBACK TRANSACTION; 
GO 
